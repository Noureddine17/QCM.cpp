#include <iostream>
using namespace std;

int main ()
{
	cout<< "Bonjour à vous!" <<endl;
	return 0;
}
